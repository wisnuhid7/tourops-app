﻿param(
    [string]$Root = "C:\tours"
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Relaunch as administrator when needed.
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$adminRole = [Security.Principal.WindowsBuiltInRole]::Administrator
if (-not $principal.IsInRole($adminRole)) {
    $args = "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`" -Root `"$Root`""
    Start-Process powershell.exe -Verb RunAs -ArgumentList $args
    exit
}

Add-Type -AssemblyName System.Drawing
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$Dirs = @(
    $Root,
    "$Root\assets\originals",
    "$Root\assets\web",
    "$Root\assets\thumbnails",
    "$Root\tours",
    "$Root\manifests",
    "$Root\logs"
)
foreach ($d in $Dirs) { New-Item -ItemType Directory -Force -Path $d | Out-Null }

Copy-Item "$ScriptDir\image_manifest.csv" "$Root\manifests\image_manifest.csv" -Force
Copy-Item "$ScriptDir\tour_manifest.csv" "$Root\manifests\tour_manifest.csv" -Force
Copy-Item "$ScriptDir\tour_image_map.csv" "$Root\manifests\tour_image_map.csv" -Force

$LogPath = "$Root\logs\processing_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
$ResultPath = "$Root\manifests\local_processing_results.csv"
$Results = New-Object System.Collections.Generic.List[object]

function Write-Log([string]$Message) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message"
    Write-Host $line
    Add-Content -Path $LogPath -Value $line -Encoding UTF8
}

function Get-LocalPath([string]$ManifestPath) {
    if ($ManifestPath -match '^[A-Za-z]:\\tours\\') {
        $relative = $ManifestPath -replace '^[A-Za-z]:\\tours\\', ''
        return Join-Path $Root $relative
    }
    return $ManifestPath
}

function Download-File([string]$Url, [string]$OutFile) {
    if (Test-Path $OutFile) { return "EXISTS" }
    $parent = Split-Path -Parent $OutFile
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    $tmp = "$OutFile.part"
    if (Test-Path $tmp) { Remove-Item $tmp -Force }
    $headers = @{ "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TourImageProcessor/1.0" }
    $last = $null
    for ($try=1; $try -le 3; $try++) {
        try {
            Invoke-WebRequest -Uri $Url -OutFile $tmp -UseBasicParsing -Headers $headers -TimeoutSec 90
            if ((Get-Item $tmp).Length -lt 1000) { throw "Downloaded file is unexpectedly small." }
            Move-Item $tmp $OutFile -Force
            return "DOWNLOADED"
        } catch {
            $last = $_.Exception.Message
            if (Test-Path $tmp) { Remove-Item $tmp -Force }
            Start-Sleep -Seconds (2 * $try)
        }
    }
    throw $last
}

function Save-JpegFit([string]$InputFile, [string]$OutputFile, [int]$MaxWidth, [int]$MaxHeight, [long]$Quality) {
    $img = $null
    $bmp = $null
    $g = $null
    try {
        $img = [System.Drawing.Image]::FromFile($InputFile)
        $scale = [Math]::Min(1.0, [Math]::Min($MaxWidth / [double]$img.Width, $MaxHeight / [double]$img.Height))
        $w = [Math]::Max(1, [int][Math]::Round($img.Width * $scale))
        $h = [Math]::Max(1, [int][Math]::Round($img.Height * $scale))
        $bmp = New-Object System.Drawing.Bitmap($w, $h)
        $bmp.SetResolution(96,96)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.Clear([System.Drawing.Color]::White)
        $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
        $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
        $g.DrawImage($img, 0, 0, $w, $h)
        $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' }
        $ep = New-Object System.Drawing.Imaging.EncoderParameters(1)
        $ep.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality, $Quality)
        $parent = Split-Path -Parent $OutputFile
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
        $bmp.Save($OutputFile, $codec, $ep)
    } finally {
        if ($g) { $g.Dispose() }
        if ($bmp) { $bmp.Dispose() }
        if ($img) { $img.Dispose() }
    }
}

function Link-Or-Copy([string]$Source, [string]$Destination) {
    $parent = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    if (Test-Path $Destination) { return }
    try {
        New-Item -ItemType HardLink -Path $Destination -Target $Source -ErrorAction Stop | Out-Null
    } catch {
        Copy-Item $Source $Destination -Force
    }
}

$Assets = Import-Csv "$ScriptDir\image_manifest.csv"
$AssetById = @{}
$total = $Assets.Count
$index = 0
foreach ($a in $Assets) {
    $index++
    $AssetById[$a.AssetID] = $a
    $original = Get-LocalPath $a.MasterOriginalPath
    $web = Get-LocalPath $a.MasterWebPath
    $thumb = Get-LocalPath $a.ThumbnailPath
    $status = ""
    $message = ""
    try {
        Write-Progress -Activity "Downloading and processing tour images" -Status "$index of $total — $($a.AssetID)" -PercentComplete (($index/$total)*100)
        $downloadStatus = Download-File $a.BestSourceURL $original
        $ext = [IO.Path]::GetExtension($original).ToLowerInvariant()
        if ($ext -eq '.webp') {
            if (-not (Test-Path $web)) { Copy-Item $original $web -Force }
            $status = "$downloadStatus; WEBP_PRESERVED"
        } else {
            if (-not (Test-Path $web)) { Save-JpegFit $original $web 1600 1200 86 }
            if (-not (Test-Path $thumb)) { Save-JpegFit $original $thumb 480 360 82 }
            $status = "$downloadStatus; PROCESSED"
        }
        $sidecar = [IO.Path]::ChangeExtension($original, '.json')
        [ordered]@{
            AssetID = $a.AssetID
            AssetSlug = $a.AssetSlug
            SourceURL = $a.BestSourceURL
            SourceHost = $a.SourceHost
            RiskFlags = $a.RiskFlags
            RightsStatus = $a.RightsStatus
            ProcessingPolicy = $a.ProcessingPolicy
            DownloadedAt = (Get-Date).ToString('o')
        } | ConvertTo-Json | Set-Content $sidecar -Encoding UTF8
        Write-Log "$($a.AssetID): $status"
    } catch {
        $status = "FAILED"
        $message = $_.Exception.Message
        Write-Log "$($a.AssetID): FAILED — $message"
    }
    $Results.Add([pscustomobject]@{
        AssetID=$a.AssetID; Status=$status; Message=$message; OriginalPath=$original; WebPath=$web; ThumbnailPath=$thumb; SourceURL=$a.BestSourceURL
    })
}
Write-Progress -Activity "Downloading and processing tour images" -Completed

# Build tour folders and sidecar tags.
$Map = Import-Csv "$ScriptDir\tour_image_map.csv"
$mapTotal = $Map.Count
$mapIndex = 0
foreach ($m in $Map) {
    $mapIndex++
    Write-Progress -Activity "Assigning images to tours" -Status "$mapIndex of $mapTotal — $($m.TourID)" -PercentComplete (($mapIndex/$mapTotal)*100)
    $a = $AssetById[$m.AssetID]
    if ($null -eq $a) { continue }
    $source = Get-LocalPath $a.MasterWebPath
    if (-not (Test-Path $source)) { $source = Get-LocalPath $a.MasterOriginalPath }
    if (-not (Test-Path $source)) { continue }
    $dest = Get-LocalPath $m.TourImagePath
    Link-Or-Copy $source $dest
    $sidecar = Get-LocalPath $m.TourSidecarPath
    [ordered]@{
        TourID = $m.TourID
        TourTitle = $m.TourTitle
        ImageOrder = [int]$m.ImageOrder
        AssetID = $m.AssetID
        AssetSlug = $m.AssetSlug
        LocalImagePath = $dest
        SourceURL = $a.BestSourceURL
        SourceHost = $a.SourceHost
        RiskFlags = $a.RiskFlags
        RightsStatus = $a.RightsStatus
        ProcessingPolicy = $a.ProcessingPolicy
    } | ConvertTo-Json | Set-Content $sidecar -Encoding UTF8
}
Write-Progress -Activity "Assigning images to tours" -Completed

$Results | Export-Csv $ResultPath -NoTypeInformation -Encoding UTF8
$success = ($Results | Where-Object { $_.Status -ne 'FAILED' }).Count
$failed = ($Results | Where-Object { $_.Status -eq 'FAILED' }).Count
Write-Log "COMPLETE: $success assets available; $failed failed."
Write-Host ""
Write-Host "Finished. Images are under $Root" -ForegroundColor Green
Write-Host "Results: $ResultPath"
Write-Host "Rights review is still required before publication." -ForegroundColor Yellow
Read-Host "Press Enter to close"
