TOUR IMAGE PROCESSOR — WINDOWS
================================

Prepared for the uploaded itinerary file.

PACKAGE CONTENTS
----------------
- START_TOUR_IMAGE_PROCESSING.bat  Double-click this file.
- Install-TourImages.ps1           Downloads, renames, resizes, tags and organizes images.
- image_manifest.csv               722 deduplicated image assets.
- tour_manifest.csv                243 tours.
- tour_image_map.csv               1306 tour-to-image assignments.
- itineraries_source.csv           Original uploaded CSV.

OUTPUT FOLDER
-------------
C:\tours

Generated structure:
C:\tours\assets\originals       Original downloaded files
C:\tours\assets\web             Website-ready derivatives when supported
C:\tours\assets\thumbnails      480-pixel thumbnails
C:\tours\tours\T0001_...         One folder for each tour
C:\tours\manifests                 Copied manifests and local processing results
C:\tours\logs                      Download and processing logs

HOW TO RUN
----------
1. Extract this ZIP to a normal folder such as Downloads.
2. Double-click START_TOUR_IMAGE_PROCESSING.bat.
3. Approve the Windows administrator prompt, because C:\tours is at the root of drive C:.
4. Keep the PowerShell window open until the completion message appears.
5. Failed downloads can be retried by running the BAT file again; existing files are skipped.

PROCESSING
----------
- Chooses the best listed source URL for each deduplicated asset.
- Downloads one master original for each asset.
- Creates a web copy up to 1600 x 1200 pixels and a thumbnail up to 480 x 360 pixels.
- Preserves aspect ratio and does not upscale small images.
- Keeps WebP files as WebP when native Windows image conversion is unavailable.
- Renames files with stable tour and image IDs.
- Creates JSON sidecar tags containing tour name, source URL and rights status.
- Uses hard links when possible to avoid duplicating identical image bytes across tours.

IMPORTANT RIGHTS RULE
---------------------
These images come from third-party travel and stock-image sources. The package preserves source URLs and ownership information. It does NOT remove company logos, watermarks or copyright marks. Before publishing, obtain permission/license or replace the image with an original or properly licensed image. The manifest marks every asset as NEEDS_PERMISSION_OR_REPLACEMENT until you confirm rights.

COUNTS
------
Tours: 243
Deduplicated assets: 722
Tour-image assignments: 1306
